<li <?= $this->app->checkMenuSelection('SkillMatrixController', '') ?>>
    <?= $this->url->link('SkillMatrix', 'SkillMatrixController', 'load', array('plugin' => 'SkillMatrix')) ?>
</li>